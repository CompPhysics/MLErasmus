This IPython notebook day4.ipynb does not require any additional
programs.
