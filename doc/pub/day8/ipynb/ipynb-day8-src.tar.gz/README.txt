This IPython notebook day8.ipynb does not require any additional
programs.
