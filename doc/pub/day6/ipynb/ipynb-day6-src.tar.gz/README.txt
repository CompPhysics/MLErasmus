This IPython notebook day6.ipynb does not require any additional
programs.
