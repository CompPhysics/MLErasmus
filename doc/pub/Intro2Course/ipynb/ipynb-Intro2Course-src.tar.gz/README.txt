This IPython notebook Intro2Course.ipynb does not require any additional
programs.
