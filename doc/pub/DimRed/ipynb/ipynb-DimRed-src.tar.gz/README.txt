This IPython notebook Dimred.ipynb does not require any additional
programs.
