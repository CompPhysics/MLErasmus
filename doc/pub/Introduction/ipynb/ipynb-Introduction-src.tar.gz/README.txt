This IPython notebook Introduction.ipynb does not require any additional
programs.
