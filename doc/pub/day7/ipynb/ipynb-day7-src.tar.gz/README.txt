This IPython notebook day7.ipynb does not require any additional
programs.
