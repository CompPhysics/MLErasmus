This IPython notebook Day2.ipynb does not require any additional
programs.
