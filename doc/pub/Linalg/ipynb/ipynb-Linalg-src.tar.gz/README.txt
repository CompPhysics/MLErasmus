This IPython notebook Linalg.ipynb does not require any additional
programs.
