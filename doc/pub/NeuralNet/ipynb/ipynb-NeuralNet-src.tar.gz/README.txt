This IPython notebook NeuralNet.ipynb does not require any additional
programs.
